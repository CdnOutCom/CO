interface Patternfly {
  pfBreakpoints: {
    tablet: number;
    desktop: number;
  };
}
interface Window {
  patternfly: Patternfly;
}
