/// <reference path="patternfly-settings-colors.d.ts" />
/// <reference path="patternfly-settings-base.d.ts" />
/// <reference path="patternfly-settings-charts.d.ts" />